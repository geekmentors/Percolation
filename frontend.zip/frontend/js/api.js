// API Configuration
const API_BASE_URL = 'http://localhost:7099/api';

// API Client
const api = {
    token: localStorage.getItem('auth_token'),

    setToken(token) {
        this.token = token;
        if (token) {
            localStorage.setItem('auth_token', token);
        } else {
            localStorage.removeItem('auth_token');
        }
    },

    getToken() {
        return this.token || localStorage.getItem('auth_token');
    },

    async request(endpoint, options = {}) {
        const token = this.getToken();

        const config = {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers,
            }
        };

        if (token) {
            config.headers['Authorization'] = `Bearer ${token}`;
        }

        try {
            const response = await fetch(`${API_BASE_URL}${endpoint}`, config);

            // Handle 401 Unauthorized - Token expired or invalid
            if (response.status === 401) {
                // Don't auto-logout for login/register endpoints
                if (!endpoint.includes('/auth/login') && !endpoint.includes('/auth/register')) {
                    this.setToken(null);
                    localStorage.removeItem('user_data');
                    alert('Session expired. Please log in again.');
                    window.location.href = 'login.html';
                    return;
                }
            }

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Request failed');
            }

            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },

    // Auth endpoints
    async register(email, password, name, licenseKey) {
        return this.request('/auth/register', {
            method: 'POST',
            body: JSON.stringify({ email, password, name, license_key: licenseKey })
        });
    },

    async login(email, password) {
        return this.request('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
    },

    async getCurrentUser() {
        return this.request('/auth/me');
    },

    async logout() {
        return this.request('/auth/logout', { method: 'POST' });
    },

    // RFP endpoints
    async uploadFile(file, language = 'English') {
        const token = this.getToken();
        const formData = new FormData();
        formData.append('file', file);
        formData.append('language', language);

        const response = await fetch(`${API_BASE_URL}/rfp/upload`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            body: formData
        });

        // Handle 401 Unauthorized - Token expired or invalid
        if (response.status === 401) {
            this.setToken(null);
            localStorage.removeItem('user_data');
            alert('Session expired. Please log in again.');
            window.location.href = 'login.html';
            return;
        }

        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'Upload failed');
        return data;
    },

    async analyzeFile(fileId, language = 'English') {
        return this.request(`/rfp/analyze/${fileId}`, {
            method: 'POST',
            body: JSON.stringify({ language })
        });
    },

    async getSummary(fileId) {
        return this.request(`/rfp/summary/${fileId}`);
    },

    async chat(fileId, question, history = [], language = 'English') {
        return this.request('/rfp/chat', {
            method: 'POST',
            body: JSON.stringify({
                file_id: fileId,
                question,
                history,
                language
            })
        });
    },

    async deleteFile(fileId) {
        return this.request(`/rfp/files/${fileId}`, { method: 'DELETE' });
    },

    // User endpoints
    async getUsage() {
        return this.request('/user/usage');
    },

    async getFiles() {
        return this.request('/user/files');
    },

    async updateLicenseKey(licenseKey) {
        return this.request('/auth/update-license', {
            method: 'PUT',
            body: JSON.stringify({ license_key: licenseKey })
        });
    },

    // Admin endpoints
    async adminLogin(username, password) {
        return this.request('/admin/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
    },

    async getUsers(page = 1) {
        return this.request(`/admin/users?page=${page}`);
    },

    async toggleUserStatus(userId, isActive) {
        return this.request(`/admin/users/${userId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ is_active: isActive })
        });
    },

    async getSetupStatus() {
        return this.request('/admin/setup-status');
    },

    async setupAdmin(username, password) {
        return this.request('/admin/setup', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
    },

    async getAnalytics() {
        return this.request('/admin/analytics');
    },

    async getAllFiles(page = 1) {
        return this.request(`/admin/files?page=${page}`);
    },

    async getLlmConfig() {
        return this.request('/admin/llm-config');
    },

    async updateLlmConfig(config) {
        return this.request('/admin/llm-config', {
            method: 'PUT',
            body: JSON.stringify(config)
        });
    }
};

// Check if user is logged in
function isLoggedIn() {
    return !!api.getToken();
}

// Redirect to login if not authenticated
function requireAuth() {
    if (!isLoggedIn()) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Logout function
function logout() {
    api.setToken(null);
    localStorage.removeItem('user_data');
    window.location.href = 'login.html';
}
